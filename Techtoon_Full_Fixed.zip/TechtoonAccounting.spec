# -*- mode: python ; coding: utf-8 -*-
from PyInstaller.utils.hooks import collect_all

datas = [('pages', 'pages'), ('.streamlit', '.streamlit'), ('input_helpers.py', '.'), ('cache_helpers.py', '.'), ('database.py', '.'), ('models.py', '.'), ('services.py', '.'), ('sidebar.py', '.'), ('navigation_helper.py', '.'), ('local_mirror.py', '.'), ('sync_manager.py', '.'), ('s3_backup.py', '.'), ('invoice_page_common.py', '.'), ('license_manager.py', '.'), ('license_ui.py', '.')]
binaries = []
hiddenimports = ['psycopg2', 'streamlit', 'boto3', 'webview']
tmp_ret = collect_all('streamlit')
datas += tmp_ret[0]; binaries += tmp_ret[1]; hiddenimports += tmp_ret[2]


a = Analysis(
    ['launcher.py'],
    pathex=[],
    binaries=binaries,
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='TechtoonAccounting',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=['logo.ico'],
)
coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='TechtoonAccounting',
)
